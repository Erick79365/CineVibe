CineVibe Android 3.0

Features: film and series catalog, search across both, favorites saved locally, TMDB poster images where supplied, generated branded poster art fallback for missing poster images, trailer search, JustWatch discovery link, video player for user-authorized direct HTTP/HTTPS media links, free sample video, and Android cast-settings shortcut (device/TV-dependent).

This app does not contain commercial films/series streams or bypass subscriptions/DRM. Use only direct media links you are authorized to play. Availability varies by Android/TV device; Cast settings shortcut is not a built-in Chromecast receiver or guaranteed screen-mirroring solution. For Samsung Smart View, use the phone's Quick Settings panel and compatible TV.

Build: Gradle assembleDebug.
