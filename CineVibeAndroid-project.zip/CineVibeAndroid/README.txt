CINEVIBE Android wrapper project

This project packages the existing CineVibe HTML prototype into an Android WebView app.

To build an APK without a PC:
1. Upload this project to a GitHub repository (extract ZIP and upload its files).
2. Open the repository Actions tab.
3. Run "Build CineVibe APK" (or push to main).
4. Open the workflow run and download the artifact named CineVibe-debug-apk.
5. Extract the artifact to obtain app-debug.apk and install it on Android.

This is a prototype wrapper. It does not yet provide licensed full-movie playback or Chromecast casting.
