CineVibe Android 3.1 — source project

Included: movie/series catalog UI, search, favorites stored locally, posters, official-trailer search, legal availability search, cast-settings shortcut, local video picker (Android file chooser) and a free sample video.

Playback now offers “Meus vídeos” to select a video from the phone. It no longer asks for a pasted direct media URL. The catalog is informational and does not include commercial movie/series streams or bypass subscriptions/DRM.

Build: Gradle assembleDebug (Android Gradle Plugin; Java 17; compile SDK 35).
